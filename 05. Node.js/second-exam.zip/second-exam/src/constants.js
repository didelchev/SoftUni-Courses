export const JWT_SECRET = 'b4b08b6daf0938b301cf1734a0409de5';
export const AUTH_COOKIE_NAME = 'auth'
export const SALT_ROUNDS = 10;